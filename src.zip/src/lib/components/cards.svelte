<script lang="ts">
    export let visible: boolean = false;
    export let message: string = '';
    export let type: string = '';
    export let title: string = '';
    export let fields: any = {};
    export let image: string = '';
    export let version: string = '';
</script>

{#if visible}

<a
  href="#"
  class="card preset-filled-surface-100-900 border-[1px] border-surface-200-800 card-hover divide-surface-200-800 block max-w-md divide-y overflow-hidden"
>
  <!-- Header -->
  <header>
    <img src={image} class="aspect-[21/9] w-full grayscale hue-rotate-90" alt="banner" />
  </header>
  <!-- Main -->
  <article class="space-y-4 p-4">
    <div>
      <h2 class="h6">{type}</h2>
      <h3 class="h3">{title}</h3>
    </div>
    <p class="opacity-60">
      {message}
    </p>
      <hr class="hr border-t-2" />
      {#each Object.entries(fields) as [key, value]}
      <div>
          <label for={key}>{key}</label>
          <input type="text" id={key} bind:value={value} />
      </div>
  {/each}

  </article>
  <!-- Footer -->
  <footer class="flex items-center justify-between gap-4 p-4">
    <small class="opacity-60">Version: {version}</small>
  </footer>
</a>
{/if}
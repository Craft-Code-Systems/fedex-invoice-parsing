// src/lib/addons/registry.server.ts
import fedexWebAddon, {
    type ife as IFEfedexWebAddon
  } from 'ccs-fedex-web-addon';
  // …import other plugins here…
  
  export const PLUGIN_REGISTRY = {
    'fedex-web': fedexWebAddon,
    // 'postnl':     postnlAddon,
  } as const;
  
  export type PluginName = keyof typeof PLUGIN_REGISTRY;
  export type PluginIFE = {
    [K in PluginName]: typeof PLUGIN_REGISTRY[K]['init'] extends () => infer I
      ? I
      : never;
  };
  
  export function getPlugin<K extends PluginName>(name: K) {
    return PLUGIN_REGISTRY[name];
  }
  
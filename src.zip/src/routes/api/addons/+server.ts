// src/routes/api/plugins/+server.ts
import type { RequestHandler } from '@sveltejs/kit';
import { PLUGIN_REGISTRY } from '$lib/addons/registry';

export const GET: RequestHandler = () => {
  // For each plugin, pull just the serializable bits
  const meta = Object.fromEntries(
    Object.entries(PLUGIN_REGISTRY).map(([key, plugin]) => [
      key,
      {
        name:          plugin.name,
        name_friendly: plugin.name_friendly,
        version:       plugin.version,
        // you can also list auth‐fields here if you want
        authFields:    Object.keys((plugin.init() as any)),
      }
    ])
  );

  return new Response(JSON.stringify(meta), {
    headers: { 'content-type': 'application/json' }
  });
};

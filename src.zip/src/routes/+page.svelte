<script lang="ts">
  import Cards from '$lib/components/cards.svelte';
  import { type PluginName,type PluginIFE , getPluginInfo} from '$lib/addons/registry';
  export let data: { plugins: Record<string, { name: string; name_friendly: string; version: string; authFields: string[] }> };

  // pick your plugin
  const pluginMeta = data.plugins['fedex-web'];
  const webFields  = pluginMeta.authFields.filter((f) => f.startsWith('web'));
const pluginImg= pluginMeta.name.split('-')[0] + ".png";
// const addon = getPluginInfo(pluginName);
// Get plugin verison
  // // create an empty auth‐template just to get its keys at runtime
  // const authTemplate = {
  //   api_bearer_token: '',
  //   web_bearer_token: '',
  //   api_client_id: '',
  //   api_client_secret: '',
  //   web_client_id: '',
  //   web_client_username: '',
  //   web_client_password: '',
  //   web_client_cookie: '',
  //   web_account_number: '',
  //   api_bearer_token_expires_at: 0,
  // } as PluginIFE[typeof pluginName]['auth'];
  // const fields = Object.keys(authTemplate);
  // const webFields = fields.filter((f) => f.startsWith('web'));
console.log("webFields:", webFields);
  const visible = true;
  const message = 'This is a message';
  const title = 'This is a title';

const imgSrc =
  'https://images.unsplash.com/photo-1463171515643-952cee54d42a?q=80&w=450&h=190&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D';
</script>

<div class="grid h-screen grid-rows-[auto_1fr_auto]">
  <!-- Header -->
	<header class="sticky top-0 z-10 bg-red-500/80 backdrop-blur-sm p-4">(header)</header>
	<!-- Main -->
	<main class="bg-green-500 p-4 space-y-4">
    <div class="grid grid-cols-4 gap-4">
      <div class="h-auto p-4">

    <Cards visible={visible} message={pluginMeta.name} title={pluginMeta.name_friendly} fields={webFields} image={pluginImg} version=$version:{pluginMeta.version}  />

    </div>
    <div>
    <p class="h-[512px] bg-purple-500 p-4">Paragraph 2</p>
  </div>
    <div>
    <p class="h-[512px] bg-purple-500 p-4">Paragraph 3</p>
  </div>
  </div>
	</main>
	<!-- Footer -->
	<footer class="bg-blue-500 p-4">(footer)</footer>
</div>
